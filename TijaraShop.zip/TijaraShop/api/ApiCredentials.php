<?php


class ApiCredentials
{
    //todo construct and define wpdb & Request here + boolean hasApiAccess
}