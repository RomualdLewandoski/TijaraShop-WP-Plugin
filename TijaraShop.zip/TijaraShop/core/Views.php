<?php


class Views extends System
{
    public function __construct()
    {

    }
}