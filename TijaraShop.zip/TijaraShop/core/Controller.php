<?php


class Controller extends System
{
    public function __construct()
    {

    }

}