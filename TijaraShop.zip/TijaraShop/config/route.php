<?php

$route['api/users'] = "api/getUsers";
$route['api/perms'] = "api/getPerms";
//$route['api/main/$?'] = "admin/test";
$route['api/main'] = "api/index";
$route['api'] = "api/index";


