<?php

$route['api/main/$?/$?/$?'] = "admin/test";
$route['api/main/$?/$?'] = "admin/test";
$route['api/main/$?'] = "admin/test";
$route['api/main'] = "admin/index";



