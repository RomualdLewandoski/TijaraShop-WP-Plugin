<?php


class Plop_Model extends Model
{

    public function __construct()
    {
        echo "<script>alert('salut')</script>";

    }
}