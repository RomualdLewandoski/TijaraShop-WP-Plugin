<?php


class Helper extends System
{
    public function __construct()
    {

    }

}