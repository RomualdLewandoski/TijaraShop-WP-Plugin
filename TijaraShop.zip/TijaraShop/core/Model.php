<?php


class Model extends System
{
    public function __construct()
    {

    }


}